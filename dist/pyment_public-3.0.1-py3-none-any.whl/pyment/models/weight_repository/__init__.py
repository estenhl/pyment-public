from .weight_repository import WeightRepository
